# SuperFastPython.com
# example of accessing the thread name
from threading import Thread
# create the thread
thread = Thread()
# report the thread name
print(thread.name)
